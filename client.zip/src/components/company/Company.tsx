import axios from 'axios';
import { Component } from 'react'
import { User } from '../../models/User';
import "./Company.css"
import Home from '../home/Home';

interface ICompanyState {
  user: User;
}

export default class Company extends Component<any, ICompanyState> {

  constructor(props: any) {
    super(props);
    this.state = { user: new User() };
  }

  private userId = sessionStorage.getItem("id");

  public async componentDidMount() {
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    try {
      const response = await axios.get<User>("http://localhost:8080/users/" + this.userId);
      const user = response.data;
      this.setState({ user });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  public render() {
    return (
      <div className="Company">
        <br />
        <h1>Welcome! {this.state.user.firstName} from {this.state.user.companyName} :)</h1>
          <br /><input type="button" value="My user details" onClick={() => this.props.history.push('/userDetails/' + this.state.user.id)} />
          <br /><input type="button" value="My company details" onClick={() => this.props.history.push('/companyDetails/' + this.state.user.companyId)} />
          <br /><input type="button" value="My company coupons" onClick={() => this.props.history.push('/coupons')} />
          <br /><input type="button" value="My company purchases" onClick={() => this.props.history.push('/purchases')} />
          <br /><input type="button" value="Create coupon" onClick={() => this.props.history.push('/createCoupon')} />
      </div>
    );
  }
}

