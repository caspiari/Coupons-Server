import axios from 'axios';
import { Component } from 'react'
import { Purchase } from '../../../models/Purchase';
import "./PurchaseDetails.css";
import Home from '../../home/Home';
import Card from '../../card/Card';

interface PurchaseDetailsState {
  purchase: Purchase;
}

export default class PurchaseDetails extends Component<any, PurchaseDetailsState> {

  constructor(props: any) {
    super(props);
    this.state = { purchase: new Purchase() };
  }

  public async componentDidMount() {
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    const id = +this.props.match.params.id;
    try {
      const response = await axios.get<Purchase>("http://localhost:8080/purchases/" + id);
      const purchase = response.data;
      this.setState({ purchase: purchase });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  private onDeleteClick = async () => {
    if (window.confirm("Do you want to delete this purchase?") === true) {
      try {
        await axios.delete("http://localhost:8080/purchases/" + this.state.purchase.id);
        alert("Purchase was successfuly deleted");
        this.props.history.goBack();
      } catch (err) {
        Home.exceptionTreatment(err, this.props);
      }
    }
  }

  public render() {
    return (
      <div className="purchaseDetails">
        <div id="purchaseDetails">
          <h2>Purchase details: (id: {this.state.purchase.id})</h2>
          <h3>Company: {this.state.purchase.companyName}</h3>
          <h3>Coupon: {this.state.purchase.couponId}:&nbsp;{this.state.purchase.couponName}</h3> {/* eslint-disable-next-line */}
          {(sessionStorage.getItem("userType") == "ADMIN" || sessionStorage.getItem("userType") == "COMPANY") && 
            <h3>User: {this.state.purchase.userId}:&nbsp;{this.state.purchase.username}</h3>}
          <h3>Amout: {this.state.purchase.amount}</h3>
          <h3>Timestamp: {Card.formatDateAndTime(this.state.purchase.timestamp)}</h3>
          {(sessionStorage.getItem("userType") === "ADMIN") && <span><br />
            <input type="button" value="Delete" onClick={this.onDeleteClick} />&nbsp;</span>}
          <input type="button" className="back" value="Back" onClick={() => this.props.history.goBack()} />
        </div>
      </div>
    );
  }
}
