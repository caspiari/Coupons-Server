import axios from 'axios';
import React from 'react';
import { Component } from 'react'
import { Coupon } from '../../models/Coupon';
import { CouponType } from '../../enums/CouponType';
import { UserType } from '../../enums/UserType';
import Card from '../card/Card';
import Home from '../home/Home';
import "./Coupons.css";
import { Company } from '../../models/Company';
import { ChangeEvent } from 'react';

interface CouponsState {
  coupons: Coupon[];
  companies: Company[];
  nameFilter: string;
  companyIdFilter: number;
  categoryFilter: string;
}

export default class Coupons extends Component<any, CouponsState> {

  private couponTypes: CouponType[];

  constructor(props: any) {
    super(props);
    this.state = { coupons: [], companies: [], nameFilter: "", companyIdFilter: 0, categoryFilter: "" };
    this.couponTypes = [CouponType.COMPUTERS, CouponType.KITCHEN, CouponType.STEREO];
  }

  public async componentDidMount() {
    try {
      if (sessionStorage.getItem("userType") !== UserType.COMPANY.valueOf()) {
        const couponsResponse = await axios.get<Coupon[]>("http://localhost:8080/coupons");
        const companiesResponse = await axios.get<Company[]>("http://localhost:8080/companies");
        this.setState({ coupons: couponsResponse.data, companies: companiesResponse.data });
      } else {
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        const id = +sessionStorage.getItem("companyId");
        const response = await axios.get<Coupon[]>("http://localhost:8080/coupons/byCompanyId", { params: { companyId: id } });
        this.setState({ coupons: response.data });
      }
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  public onNamePipeChanged = (event: React.ChangeEvent<HTMLInputElement>) => {
    let nameFilter = event.target.value;
    this.setState({ nameFilter });
  }

  private onCompanyPipeChanged = (event: ChangeEvent<HTMLSelectElement>) => {
    const companyIdFilter = +event.target.value;
    this.setState({ companyIdFilter });
}

  public onCategoryPipeChanged = (event: React.ChangeEvent<HTMLSelectElement>) => {
    let categoryFilter = event.target.value;
    this.setState({ categoryFilter });
  }

  public render() {
    return (
      <div className="coupons">
        {/* eslint-disable-next-line */}
        <h2>{sessionStorage.getItem("userType") == "COMPANY" ? "Your" : "Our"} coupons</h2>
        {/* eslint-disable-next-line */}
        {(sessionStorage.getItem("userType") == "COMPANY" || sessionStorage.getItem("userType") == "ADMIN") 
         && <input type="button" id="button" value="Create new" onClick={() => this.props.history.push('/createCoupon')} />}
       <br /><br /><span className="translateDown"><b>Search:</b> <input type="text" placeholder="By name" onChange={this.onNamePipeChanged} /></span>
        {sessionStorage.getItem("userType") !== "COMPANY" && <span>
          <select name="companySelect" onChange={this.onCompanyPipeChanged}>
            <option value={0} key="defaultCompany">By company:</option>
            {this.state.companies.map((Company, index) => (<option value={Company.id} key={index}>{Company.name}</option>))}
          </select> </span>}
          <select name="coupon type select" id="category" onChange={this.onCategoryPipeChanged}>
          <option value="" key="defaultCategory">By category:</option>
              {(this.couponTypes).map((couponType, index) => (
                  <option value={couponType.valueOf()} key={index}>{couponType.valueOf()}</option>))}
          </select><br />
        <br />
        {<ol>
          {this.state.coupons.filter(coupon => coupon.name.toLowerCase().includes(this.state.nameFilter.toLowerCase())) // eslint-disable-next-line
          .filter(user => this.state.companyIdFilter == 0? true : user.companyId == this.state.companyIdFilter)
          .filter(coupon => coupon.category.valueOf().includes(this.state.categoryFilter))
          .map(coupon => <Card key={coupon.id} coupon={coupon} onCardClick={() => this.props.history.push('/couponDetails/' + coupon.id)} />)}
        </ol>}
        <br /><input type="button" id="button" className="backButton" value="Back" onClick={() => this.props.history.goBack()} />
      </div>
    );
  }
}
