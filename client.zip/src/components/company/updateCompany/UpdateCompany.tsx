import { Component } from 'react';
import axios from "axios";
import "./UpdateCompany.css";
import { ChangeEvent } from 'react';
import { Company } from '../../../models/Company';
import Home from '../../home/Home';

interface IUpdateCompanyState {
    id: number,
    name: string,
    address: string,
    phone: string,
    successfulUpdate: boolean
}

export default class UpdateCompany extends Component<any, IUpdateCompanyState> {

    public constructor(props: any) {
        super(props);
        this.state = { id: 0, name: "", address: "", phone: "", successfulUpdate: false };
    }

    public async componentDidMount() {
        try {
            const token = sessionStorage.getItem("token");
            axios.defaults.headers.common["Authorization"] = token;
            const id = this.props.match.params.id;
            const response = await axios.get<Company>("http://localhost:8080/companies/" + id);
            const company = response.data;
            this.setState({ id: company.id, name: company.name, address: company.address, phone: company.phone });
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private setName = (event: ChangeEvent<HTMLInputElement>) => {
        let name = event.target.value;
        this.setState({ name });
    }

    private setAddress = (event: ChangeEvent<HTMLInputElement>) => {
        let address = event.target.value;
        this.setState({ address });
    }

    private setPhone = (event: ChangeEvent<HTMLInputElement>) => {
        let phone = event.target.value;
        this.setState({ phone });
    }

    private onEditClick = async () => {
        const company = new Company(this.state.id, this.state.name, this.state.address, this.state.phone);
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        try {
            await axios.put("http://localhost:8080/companies", company);
            alert("Company was successfuly edited");
            this.props.history.goBack();
        }
        catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    public render() {
        return (
            <div className="update">
                <h2>Update company: Id: {this.state.id}</h2>
                <span className="titles">
                    Name: <br />
                    Address: <br />
                    Phone: <br />
                </span>
                <span className="text-boxes">
                    <input type="text" name="name" id="name" placeholder={this.state.name} value={this.state.name} onChange={this.setName} /><br />
                    <input type="text" name="address" id="address" value={this.state.address} onChange={this.setAddress} /><br />
                    <input type="number" name="phone" value={this.state.phone} onChange={this.setPhone} /><br />
                </span>
                <br />
                <input type="button" id="button" value="Edit" onClick={this.onEditClick} />
                <input type="button" id="button" value="Close" onClick={() => this.props.history.goBack()} /><br /><br />
            </div>
        );
    }

}


