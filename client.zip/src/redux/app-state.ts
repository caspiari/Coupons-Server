import { UserType } from "../enums/UserType";

export class AppState {
    public userType: UserType = null;
}