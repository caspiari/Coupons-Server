import { Component } from 'react';
import axios from "axios";
import "./UpdateUser.css";
import { UserType } from '../../../enums/UserType';
import { User } from '../../../models/User';
import { ChangeEvent } from 'react';
import Home from '../../home/Home';
import { Company } from '../../../models/Company';

interface IUpdateUserState {
    user: User;
    userTypes: string[];
    companies: Company[];
    isCompanySelected: boolean;
}

export default class UpdateUser extends Component<any, IUpdateUserState> {

    private userType: UserType; //Outside of the state for not to rerender the component when changes
    private companyId: number;

    public constructor(props: any) {
        super(props);
        this.state = {
            user: new User(), userTypes: ["ADMIN", "COMPANY", "CUSTOMER"], companies: [], isCompanySelected: false
        };
        this.userType = UserType.CUSTOMER;
        this.companyId = 0;
    }

    public async componentDidMount() {
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        try {
            const id = this.props.match.params.id;
            const userResponse = await axios.get<User>("http://localhost:8080/users/" + id);
            const user = userResponse.data;
            const companiesResponse = await axios.get<Company[]>("http://localhost:8080/companies");
            let isCompanySelected; // eslint-disable-next-line
            if (sessionStorage.getItem("userType") == "ADMIN" && user.userType == UserType.COMPANY) {
                isCompanySelected = true;
            }
            this.setState({ user: user, companies: companiesResponse.data, isCompanySelected });
            this.userType = user.userType;
            this.companyId = user.companyId;
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private setUsername = (event: ChangeEvent<HTMLInputElement>) => {
        let user = { ...this.state.user };
        user.username = event.target.value;
        this.setState({ user });
    }

    private setPassword = (event: ChangeEvent<HTMLInputElement>) => {
        let user = { ...this.state.user };
        user.password = event.target.value;;
        this.setState({ user });
    }

    private setFirstName = (event: ChangeEvent<HTMLInputElement>) => {
        let user = { ...this.state.user };
        user.firstName = event.target.value;
        this.setState({ user });
    }

    private setLastName = (event: ChangeEvent<HTMLInputElement>) => {
        let user = { ...this.state.user };
        user.lastName = event.target.value;
        this.setState({ user });
    }

    private setUserType = (event: ChangeEvent<HTMLSelectElement>) => {
        this.userType = event.target.value as UserType;
        // eslint-disable-next-line
        this.userType == UserType.COMPANY ? this.setState({ isCompanySelected: true }) : this.setState({ isCompanySelected: false });
    }

    private setCompanyId = (event: ChangeEvent<HTMLSelectElement>) => {
        this.companyId = +event.target.value;
    }

    private onEditClick = async () => {
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token; // eslint-disable-next-line
        let user = {...this.state.user};
        user.userType = this.userType;
        user.companyId = this.companyId;
        try {
            await axios.put("http://localhost:8080/users", user);
            alert("User was successfuly edited");
            this.props.history.goBack();
        }
        catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    public render() {
        return (
            <div className="update">  {/* eslint-disable-next-line */}
                <h2>Update user: Id: {this.state.user.id} {sessionStorage.getItem("userType") != "ADMIN" && `(Please reenter your password)`}</h2>
                <span className="titles">
                    <label htmlFor="username">User name: </label><br />{/* eslint-disable-next-line*/}
                    <label htmlFor="password">Password: </label><br />
                    <label htmlFor="firstName">First name: </label><br />
                Last name: <br />{/* eslint-disable-next-line*/}
                    {sessionStorage.getItem("userType") == "ADMIN" && <span>User type: <br /></span>}
                    {this.state.isCompanySelected && `Company: `}
                </span>
                <span className="text-boxes">
                    <input type="text" name="username" placeholder="E-mail" value={this.state.user.username} onChange={this.setUsername} /><br />{/* eslint-disable-next-line*/}
                    <input type="password" name="password" value={this.state.user.password} onChange={this.setPassword} /><br />
                    <input type="text" name="firstName" value={this.state.user.firstName} onChange={this.setFirstName} /><br />
                    <input type="text" name="lastName" value={this.state.user.lastName} onChange={this.setLastName} /><br />
                    {/* eslint-disable-next-line*/}
                    {sessionStorage.getItem("userType") == "ADMIN" && <select name="userTypeSelect" onChange={this.setUserType}>
                        <option defaultValue={this.state.user.userType} key="defaultValue">{this.state.user.userType}</option>
                        {/* eslint-disable-next-line*/}
                        {this.state.userTypes.filter(userType => userType != this.state.user.userType).map((userType, index) => (
                            <option value={userType} key={index}>{userType}</option>))}
                    </select>}
                    {this.state.isCompanySelected && <div>
                        <select name="company select" onChange={this.setCompanyId}>
                            {this.state.user.companyId == null ? <option disabled key="default">-- Select company --</option>
                                : <option defaultValue={this.state.user.companyId} key="defaultCompany">{this.state.user.companyName}</option>}
                            {this.state.user.companyId == null ? this.state.companies.map((company, index) => (<option value={company.id} key={index}>{company.name}</option>))
                                : this.state.companies.filter(company => company.id !== this.state.user.companyId)
                                    .map((company, index) => (<option value={company.id} key={index}>{company.name}</option>))}
                        </select>
                    </div>}
                </span>
                <br />
                <input type="button" id="button" value="Edit" onClick={this.onEditClick} />
                <input type="button" id="button" value="Back" onClick={() => this.props.history.goBack()} /><br />
            </div>
        );
    }

}


