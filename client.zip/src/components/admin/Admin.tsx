import { Component } from 'react'
import "./Admin.css"

export default class Admin extends Component<any> {

    public render() {
        return (
            <div className="admin">
                <br />
                <h2>Hello admin</h2><br />
                <br /><input type="button" value="Users management" onClick={() => this.props.history.push("/usersManagement")} />
                <br /><input type="button" value="Companies management" onClick={() => this.props.history.push("/companiesManagement")} />
                <br /><input type="button" value="Coupons management" onClick={() => this.props.history.push("/coupons")} />
                <br /><input type="button" value="Purchases management" onClick={() => this.props.history.push("/purchases")} />
            </div>
        );
    }
}
