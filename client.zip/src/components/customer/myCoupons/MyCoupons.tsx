import axios from 'axios';
import React from 'react';
import { Component } from 'react'
import { Coupon } from '../../../models/Coupon';
import { CouponType } from '../../../enums/CouponType';
import Card from '../../card/Card';
import Home from '../../home/Home';
import './MyCoupons.css';
import { Company } from '../../../models/Company';

interface IMyCouponsState {
  coupons: Coupon[];
  companies: Company[];
  nameFilter: string;
  companyIdFilter: number;
  categoryFilter: string;
}

export default class MyCoupons extends Component<any, IMyCouponsState> {

  private couponTypes: CouponType[] = [CouponType.COMPUTERS, CouponType.KITCHEN, CouponType.STEREO];

  constructor(props: any) {
    super(props);
    this.state = { coupons: [], companies: [], nameFilter: "", companyIdFilter: 0, categoryFilter: "" };
  }

  public async componentDidMount() {
    const id = +sessionStorage.getItem("id");
    const token = sessionStorage.getItem("token");
    try {
      axios.defaults.headers.common["Authorization"] = token;
      let response = await axios.get<Coupon[]>("http://localhost:8080/coupons/byUserId/?id=" + id);
      const coupons = response.data;
      response = await axios.get<Company[]>("http://localhost:8080/companies"); //For search by company
      const companies = response.data;
      this.setState({ coupons: coupons, companies: companies });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  public onNamePipeChanged = (event: React.ChangeEvent<HTMLInputElement>) => {
    let text = event.target.value;
    this.setState({ nameFilter: text });
  }

  public onCompanyPipeChanged = (event: React.ChangeEvent<HTMLSelectElement>) => {
    let companyFilter = +event.target.value;
    this.setState({ companyIdFilter: companyFilter });
  }

  public onCategoryPipeChanged = (event: React.ChangeEvent<HTMLSelectElement>) => {
    let categoryFilter = event.target.value.valueOf();
    this.setState({ categoryFilter });
  }


  public render() {
    return (
      <div className="myCoupons">
        <br />
        <h2>My purchased coupons:</h2><br />
        <b>Search by: </b><input type="text" placeholder="Name" onChange={this.onNamePipeChanged} />
        <select name="companySelect" onChange={this.onCompanyPipeChanged}>
            <option value={0} key="defaultCompany">Company:</option>
            {this.state.companies.map((Company, index) => (<option value={Company.id} key={index}>{Company.name}</option>))}
          </select>
        <select name="coupon type select" id="category" onChange={this.onCategoryPipeChanged}>
          <option value="" key="defaultCategory">Category:</option>
          {(this.couponTypes).map((couponType, index) => (
            <option value={couponType.valueOf()} key={index}>{couponType.valueOf()}</option>))}
        </select>
        {<ol>
          {this.state.coupons.filter(coupon => coupon.name.toLowerCase().includes(this.state.nameFilter.toLowerCase())) // eslint-disable-next-line
            .filter(coupon => this.state.companyIdFilter == 0? true : coupon.companyId == this.state.companyIdFilter)
            .filter(coupon => coupon.category.valueOf().includes(this.state.categoryFilter))
            .map(coupon => <Card key={coupon.id} coupon={coupon} onCardClick={() => this.props.history.push('/couponDetails/' + coupon.id)} />)}
        </ol>}
        <br /><input type="button" id="button" className="back" value="Back" onClick={() => this.props.history.goBack()} />
      </div>
    );
  }
}
