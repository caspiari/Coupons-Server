import axios from 'axios';
import { ChangeEvent } from 'react';
import { Component } from 'react'
import { Company } from '../../../models/Company';
import { UserType } from '../../../enums/UserType';
import Home from '../../home/Home';
import "../Register.css";

interface IIfAdminProps {
  setUserType: any;
  setCompanyId: any;
}

interface IIfAdminState {
  companies: Company[];
  companyIsSelected: boolean;
}

export default class IfAdmin extends Component<IIfAdminProps, IIfAdminState> {

  private userTypes: UserType[];

  public constructor(props: any) {
    super(props);
    this.state = { companies: [], companyIsSelected: false };
    this.userTypes = [UserType.ADMIN, UserType.COMPANY, UserType.CUSTOMER];
  }

  public async componentDidMount() {
    const token = sessionStorage.getItem("token");
    try {
        axios.defaults.headers.common["Authorization"] = token;
        const response = await axios.get<Company[]>("http://localhost:8080/companies");
        const companies = response.data;
        this.setState({ companies });
    } catch (err) {
        Home.exceptionTreatment(err, this.props);
    }
}

private onUserTypeSelect = (event: ChangeEvent<HTMLSelectElement>) => {
  const userType = event.target.value as UserType;
  if (userType === UserType.COMPANY) {
    this.setState({ companyIsSelected: true });
  } else {
    this.setState({ companyIsSelected: false });
  }
  this.props.setUserType(userType);
}

  public render() {
    return (
      <div className="register">
        User type:&nbsp;&nbsp;
        <select name="userTypeSelect" onChange={this.onUserTypeSelect}>
          <option disabled selected key="defaultUserType">-- Select user type --</option>
          {this.userTypes.map((userType, index) => (
            <option value={userType} key={index}>{userType.valueOf()}</option>))}
        </select>
        {this.state.companyIsSelected && <div>Company:&nbsp;
          <select name="companySelect" onChange={() => this.props.setCompanyId}>
            <option disabled selected key="defaultCompany">-- Select company --</option>
            {this.state.companies.map((Company, index) => (<option value={Company.id} key={index}>{Company.name}</option>))}
          </select>
        </div>}
      </div>
    );
  }
}