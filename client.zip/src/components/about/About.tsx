import { Component } from 'react'
import "./About.css";
import info from './info.png';

export default class About extends Component {
    public render() {
        return (
            <div className="about">
                <table>
                    <thead>
                        <tr className="tableHead">
                            <th className="detail">
                                <img src={info} alt="" />
                            </th>
                            <th>
                                <b>Our company</b><br />
                            We are coupons for all LTD.
                            </th>
                            <th className="detail">
                                <img src={info} alt="" />
                            </th>
                            <th>
                                <b>Contact us</b><br />
                            Dizingof st. 108 Tel-Aviv<br />
                            For customer service call: 056-7843654
                            </th>
                            <th className="detail">
                                <img src={info} alt="" />
                            </th>
                            <th>
                                <b>Responsability</b><br />
                            All the products in our site are covered<br />
                            If you have any problem please call our customer service 
                            </th>
                        </tr>
                    </thead>
                </table>
            </div>

        );
    }
}
