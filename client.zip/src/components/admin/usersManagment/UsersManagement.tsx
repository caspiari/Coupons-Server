import { Component } from 'react'
import "./UsersManagement.css"
import { User } from '../../../models/User';
import axios from 'axios';
import { ChangeEvent } from 'react';
import Home from '../../home/Home';
import { Company } from '../../../models/Company';

interface IUsersManagementState {
    userIdFilter: number;
    userNameFilter: string;
    companyIdFilter: number;
    users: User[];
    companies: Company[];
}

export default class UsersManagement extends Component<any, IUsersManagementState> {

    constructor(props: any) {
        super(props);
        this.state = { userIdFilter: 0, userNameFilter: "", companyIdFilter: 0, users: [], companies: [] };
    }

    public async componentDidMount() {
        try {
            const token = sessionStorage.getItem("token");
            axios.defaults.headers.common["Authorization"] = token;
            const usersResponse = await axios.get<User[]>("http://localhost:8080/users");
            const companyResponse = await axios.get<Company[]>("http://localhost:8080/companies");
            const users = usersResponse.data;
            const companies = companyResponse.data;
            this.setState({ users, companies });
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private onUserNamePipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let userNameFilter = event.target.value;
        this.setState({ userNameFilter });
    }

    private onUserIdPipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let userIdFilter = +event.target.value;
        this.setState({ userIdFilter });
    }

    private onCompanyPipeChanged = (event: ChangeEvent<HTMLSelectElement>) => {
        const companyIdFilter = +event.target.value;
        this.setState({ companyIdFilter });
    }

    public render() {
        return (
            <div className="usersManagement">
                <h2>Users management</h2>
                <input type="button" value="Register new user" onClick={() => this.props.history.push("/registerUser")} /><br /><br />
                <b>Search by: </b><input type="text" id="name" placeholder="User name" onChange={this.onUserNamePipeChanged} />
                    <input type="number" id="id" placeholder="ID" onChange={this.onUserIdPipeChanged} />
                    <select name="companySelect" onChange={this.onCompanyPipeChanged}>
                    <option value={0} key="defaultCompany"> Company:</option>
                    {this.state.companies.map((Company, index) => (<option value={Company.id} key={index}>{Company.name}</option>))}
                </select>
                <br />
                <table>
                    <thead>
                        <tr className="tableHead">
                            <th>ID</th>
                            <th>User name</th>
                            <th>Full name</th>
                            <th>User type</th>
                            <th>Company</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.users.filter(user => user.username.includes(this.state.userNameFilter))
                                .filter(user => this.state.userIdFilter === 0 ? true : user.id === this.state.userIdFilter)
                                .filter(user => this.state.companyIdFilter === 0 ? true : user.companyId === this.state.companyIdFilter)
                                .map((user, index) =>
                                    <tr key={user.id}>
                                        <td>{user.id}</td>
                                        <td>{user.username}</td>
                                        <td>{user.firstName} {user.lastName}</td>
                                        <td>{user.userType}</td>
                                        <td>{user.companyName}</td>
                                        <td className="tableButton"><input type="button" value="Show details" onClick={() => this.props.history.push("/userDetails/" + user.id)} /></td>
                                    </tr>
                                )
                        }
                    </tbody>
                </table>
                <br /><input type="button" value="Back" className="back" onClick={() => this.props.history.goBack()} /><br /><br />
            </div>
        );
    }
}