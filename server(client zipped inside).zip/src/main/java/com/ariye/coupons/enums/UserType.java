package com.ariye.coupons.enums;

public enum UserType {
    CUSTOMER, ADMIN, COMPANY;
}
