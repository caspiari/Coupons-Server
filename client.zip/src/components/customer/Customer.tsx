import axios from 'axios';
import { Component } from 'react'
import { User } from '../../models/User';
import Home from '../home/Home';
import './Customer.css';

interface ICustomerState {
  user: User;
}

export default class Customer extends Component<any, ICustomerState> {

  constructor(props: any) {
    super(props);
    this.state = { user: new User() }
  }

  public async componentDidMount() {
    const id: number = +sessionStorage.getItem("id");
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    try {
      const response = await axios.get<User>("http://localhost:8080/users/" + id);
      const user = response.data;
      this.setState({ user: user });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  private onMyDetailsClick = () => {
    this.props.history.push('/userDetails/' + this.state.user.id);
  }

  public render() {
    return (
      <div className="customer">
        <h1>Hello {this.state.user.firstName} :)</h1>
        <div>
          <br /><input type="button" value="My details" onClick={this.onMyDetailsClick} />
          <br /><input type="button" value="My coupons" onClick={() => this.props.history.push('/myCoupons')} />
          <br /><input type="button" value="My purchases" onClick={() => this.props.history.push('/purchases')} />
          <br /><input type="button" value="All coupons" onClick={() => this.props.history.push('/coupons')} />
        </div>
      </div>
    );
  }
}
