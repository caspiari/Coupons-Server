import axios from 'axios';
import { Component } from 'react'
import { User } from '../../../models/User';
import Home from '../../home/Home';
import "./UserDetails.css";

interface IUserDetailsState {
  user: User;
}

export default class UserDetails extends Component<any, IUserDetailsState> {

  constructor(props: any) {
    super(props);
    this.state = { user: new User() };
  }

  public async componentDidMount() {
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    try {
      const id = this.props.match.params.id;
      const response = await axios.get<User>("http://localhost:8080/users/" + id);
      const user = response.data;
      this.setState({ user });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  private onDeleteClick = async () => {
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    if (window.confirm("Do you want to delete this user?") === true) {
      try {
        await axios.delete("http://localhost:8080/users/" + this.state.user.id);
        alert("User was successfuly deleted");
        this.props.history.goBack();
      } catch (err) {
        Home.exceptionTreatment(err, this.props);
      }
    }
  }

  public render() {
    return (
      <div className="userDetails">
        <h2>User details:</h2>
        <h3>Id: {this.state.user.id}<br />
        User name: {this.state.user.username}<br />
        Name: {this.state.user.firstName} {this.state.user.lastName}<br />
        Type: {this.state.user.userType}<br />
          {this.state.user.companyId != null && `Company: ${this.state.user.companyId}, ${this.state.user.companyName}`}</h3>
        <br /><br /> {/* eslint-disable-next-line */}
         <input type="button" value="Edit" onClick={() => this.props.history.push("/updateUser/" + this.state.user.id)} />{/* eslint-disable-next-line */}
        {sessionStorage.getItem("userType") == "ADMIN" && <input type="button" value="Delete" onClick={this.onDeleteClick} />}
        <input type="button" value="Back" onClick={() => this.props.history.goBack()} /><br />
      </div>
    );
  }
}
