import axios from 'axios';
import { Component } from 'react'
import { Coupon } from '../../../models/Coupon';
import { Purchase } from '../../../models/Purchase';
import Card from '../../card/Card';
import "./CouponDetails.css";
import Home from '../../home/Home';
import UpdateCoupon from '../updateCoupon/UpdateCoupon';
import React from 'react';

interface CouponDetailsState {
  coupon: Coupon;
  purchaseAmount: number;
  editMode: boolean;
  newId: number;
  purchaseClicked: boolean;
}

export default class CouponDetails extends Component<any, CouponDetailsState> {

  constructor(props: any) {
    super(props);
    this.state = {
      coupon: new Coupon(), purchaseAmount: 0, editMode: false, purchaseClicked: false, newId: 0
    };
  }

  public async componentDidMount() {
    const token = sessionStorage.getItem("token");
    axios.defaults.headers.common["Authorization"] = token;
    const id = +this.props.match.params.id;
    try {
      const response = await axios.get<Coupon>("http://localhost:8080/coupons/" + id);
      const coupon = response.data;
      this.setState({ coupon });
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  private onPurchaseAmountChanged = (event: React.ChangeEvent<HTMLInputElement>) => {
    const purchaseAmount = +event.target.value;
    this.setState({ purchaseAmount });
  }

  private onPurchaseClick = async () => {
    this.setState({ purchaseClicked: true });
    try {
      const userId = sessionStorage.getItem("userId");
      const purchase = new Purchase(null, this.state.coupon.id, +userId, this.state.purchaseAmount, null, this.state.coupon.name);
      const response = await axios.post<number>("http://localhost:8080/purchases", purchase);
      let coupon = this.state.coupon;
      coupon.amount -= this.state.purchaseAmount;
      const serverResponse = response.data;
      this.setState({ newId: serverResponse, coupon: coupon, purchaseClicked: false });
      alert("Successful purchase! Your purchase id is: " + this.state.newId);
    } catch (err) {
      Home.exceptionTreatment(err, this.props);
    }
  }

  private onDeleteClick = async () => {
    if (window.confirm("Do you want to delete this coupon?") === true) {
      try {
        await axios.delete("http://localhost:8080/coupons/" + this.state.coupon.id);
        alert("Coupon was successfuly deleted");
        this.props.history.goBack();
      } catch (err) {
        Home.exceptionTreatment(err, this.props);
      }
    }
  }

  private setEditMode = (edited: boolean) => {
    if (edited) {
      this.componentDidMount();
    }
    this.setState({ editMode: !this.state.editMode });
  }

  public render() {
    return (
      <div className="CouponDetails">
        {!this.state.editMode && <div id="couponDetails">
          <h2 id="h2">Coupon details: (id: {this.state.coupon.id})</h2>
          <h3>Company: {this.state.coupon.companyName}</h3>
          <h3>Category: {this.state.coupon.category}</h3>
          <h3>Name: {this.state.coupon.name}</h3>
          <h3>Description: {this.state.coupon.description}</h3>
          <h3>Price: {this.state.coupon.price}</h3>
          <h3>Units left: {this.state.coupon.amount}</h3>
          <h3>Start date: {Card.formatDate(this.state.coupon.startDate)}</h3>
          <h3>End date: {Card.formatDate(this.state.coupon.endDate)}</h3>
          {sessionStorage.getItem("userType") === "CUSTOMER"
            && <div id="amountInput"><h3>How many I want:</h3><input type="number" id="number" onChange={this.onPurchaseAmountChanged} />
              {this.state.purchaseClicked ? <input type="button" disabled value="Purchase" onClick={this.onPurchaseClick} />
                : <input type="button" value="Purchase" onClick={this.onPurchaseClick} />}</div>}
          {(sessionStorage.getItem("userType") === "ADMIN" || sessionStorage.getItem("userType") === "COMPANY") && <span id="adminButtons">
            <input type="button" value="Delete" onClick={this.onDeleteClick} />
            <input type="button" value="Edit" onClick={() => this.setEditMode(false)} /></span>}
          <br /><input type="button" id="back" value="Back" onClick={() => this.props.history.goBack()} />
        </div>}
        {this.state.editMode && <UpdateCoupon coupon={this.state.coupon} setEditMode={this.setEditMode} />}
      </div>
    );
  }
}
