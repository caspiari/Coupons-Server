import { Component } from 'react'
import "./Purchases.css"
import axios from 'axios';
import { ChangeEvent } from 'react';
import { Purchase } from '../../models/Purchase';
import { Company } from '../../models/Company';
import Home from '../home/Home';

interface IPurchasesState {
    purchases: Purchase[];
    companies: Company[];
    purchaseIdFilter: number;
    userIdFilter: number;
    dateFilter: any;
    couponNameFilter: string;
    couponIdFilter: number;
}

export default class Purchases extends Component<any, IPurchasesState> {

    constructor(props: any) {
        super(props);
        this.state = {
            purchases: [], companies: [], purchaseIdFilter: 0, dateFilter: "", userIdFilter: 0,
            couponNameFilter: "", couponIdFilter: 0
        };
    }

    public async componentDidMount() {
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        const userType = sessionStorage.getItem("userType");
        let response;
        let companiesResponse;
        try { // eslint-disable-next-line
            if (userType == "ADMIN") {
                companiesResponse = await axios.get<Company[]>("http://localhost:8080/companies"); //For search by company
                response = await axios.get<Purchase[]>("http://localhost:8080/purchases"); // eslint-disable-next-line
            } else if (userType == "CUSTOMER") {
                const id = sessionStorage.getItem("id");
                response = await axios.get<Purchase[]>("http://localhost:8080/purchases/byUserId", { params: { id: id } });
            } else {
                const companyId = sessionStorage.getItem("companyId");
                response = await axios.get<Purchase[]>("http://localhost:8080/purchases/byCompanyId", { params: { id: companyId } });
            }
            const companies = companiesResponse != null ? companiesResponse.data : [];
            const purchases = response.data;
            this.setState({ purchases: purchases, companies: companies }); // eslint-disable-next-line
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private onPurchaseIdPipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let purchaseIdFilter = +event.target.value;
        this.setState({ purchaseIdFilter });
    }

    private onUserIdPipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let userIdFilter = +event.target.value;
        this.setState({ userIdFilter });
    }

    private onDatePipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let dateFilter = new Date(event.target.value);
        this.setState({ dateFilter });
    }

    private onCompanyIdPipeChanged = async (event: ChangeEvent<HTMLSelectElement>) => {
        const companyId = +event.target.value;
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        try {
            let response; // eslint-disable-next-line
            if (companyId == 0) {
                response = await axios.get<Purchase[]>("http://localhost:8080/purchases");
            } else {
                response = await axios.get<Purchase[]>("http://localhost:8080/purchases/byCompanyId", { params: { id: companyId } });
            }
            const purchases = response.data;
            this.setState({ purchases: purchases });
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private couponNamePipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let couponNameFilter = event.target.value;
        this.setState({ couponNameFilter });
    }

    private onCouponIdPipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        const couponIdFilter = +event.target.value;
        this.setState({ couponIdFilter: couponIdFilter });
    }

    private formatTime(time) {
        let date = new Date(time);
        return date.toLocaleString();
    }

    onFocus = () => {
        this.setState({ dateFilter: new Date() });
    }
    onBlur = () => {
        this.setState({ dateFilter: "" });
    }

    private compareDates = (date1: Date, timestamp: Date) => { // eslint-disable-next-line
        let date2 = new Date(timestamp); // eslint-disable-next-line
        return (date1.toDateString() == date2.toDateString());
    }

    public render() {
        return (
            <div className="purchases">
                {/* eslint-disable-next-line  */}<br />
                <h2>{sessionStorage.getItem("userType") == "ADMIN" ? "Purchases management" : "Your purchases"}</h2> {/* eslint-disable-next-line  */}
                {sessionStorage.getItem("userType") == "ADMIN" && <input type="button" id="newPurchase" value="New purchase" onClick={() => this.props.history.push("/newPurchase")} />}
                <div className="searchLine">
                    <b>Search By: </b>Purchase id: <input type="number" id="id-search-box" onChange={this.onPurchaseIdPipeChanged} />
                Date: <input type="date" id="date" onChange={this.onDatePipeChanged} />
                    {/*  placeholder="Date:" onFocus={this.onFocus} onBlur={this.onBlur} */}
                    <input type="button" id="clearDate" value="Clear" onClick={() => this.setState({ dateFilter: "" })} /><br /></div> {/* eslint-disable-next-line  */}
                {(sessionStorage.getItem("userType") == "ADMIN" || sessionStorage.getItem("userType") == "COMPANY") && <span>
                    Buyer id: <input type="number" id="id-search-box" onChange={this.onUserIdPipeChanged} /></span>} {/* eslint-disable-next-line */}
                {sessionStorage.getItem("userType") == "ADMIN" && <span>Company: <select name="companySelect" id="search-box" onChange={this.onCompanyIdPipeChanged}>
                    <option value={0} key="default company">-- Select company --</option>
                    {this.state.companies.map((Company, index) => (<option value={Company.id} key={index}>{Company.name}</option>))}
                </select></span>}
                Coupon: <input type="text" id="search-box" placeholder="Name" onChange={this.couponNamePipeChanged} />
                <input type="number" id="id-search-box" placeholder="ID" onChange={this.onCouponIdPipeChanged} /> {/* eslint-disable-next-line  */}
                {this.state.purchases.length == 0 && <h2 id="noPurchases">You have no purchases ;-/</h2>}
                {this.state.purchases.length > 0 && <div><table>
                    <thead>
                        <tr className="tableHead">
                            <th className="idTh">ID</th>
                            <th className="couponTh">Coupon / Company</th> {/* eslint-disable-next-line */}
                            {(sessionStorage.getItem("userType") == "ADMIN" || sessionStorage.getItem("userType") == "COMPANY") && <span>
                                <th className="buyerTh">Buyer id</th></span>}
                            <th className="amountTh">Amount</th>
                            <th className="timestampTh">Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        {     // eslint-disable-next-line
                            this.state.purchases.filter(purchase => this.state.purchaseIdFilter == 0 ? true : purchase.id == this.state.purchaseIdFilter) // eslint-disable-next-line
                                .filter(purchase => { // eslint-disable-next-line
                                    if (this.state.dateFilter == "") {
                                        return true;
                                    }
                                    return this.compareDates(this.state.dateFilter, purchase.timestamp);
                                }) // eslint-disable-next-line
                                .filter(purchase => this.state.userIdFilter == 0 ? true : purchase.userId == this.state.userIdFilter)
                                .filter(purchase => purchase.couponName.includes(this.state.couponNameFilter)) // eslint-disable-next-line
                                .filter(purchase => this.state.couponIdFilter == 0 ? true : purchase.couponId == this.state.couponIdFilter)
                                .map((purchase, index) =>
                                    <tr key={purchase.id}>
                                        <td>{purchase.id}</td>
                                        <td>{purchase.couponId}: {purchase.couponName}. {purchase.companyName}</td> {/* eslint-disable-next-line */}
                                        {(sessionStorage.getItem("userType") == "ADMIN" || sessionStorage.getItem("userType") == "COMPANY") && <td>{purchase.userId}</td>}
                                        <td>{purchase.amount}</td>
                                        <td>{this.formatTime(purchase.timestamp)}</td>
                                        <td className="button"><input type="button" value="Show details" onClick={() => this.props.history.push("/purchaseDetails/" + purchase.id)} /></td>
                                    </tr>
                                )
                        }
                    </tbody>
                </table></div>}
                <input type="button" id="back" value="Back" onClick={() => this.props.history.goBack()} />
            </div>
        );
    }
}