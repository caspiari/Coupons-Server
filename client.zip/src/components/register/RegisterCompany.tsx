import { Component, ChangeEvent } from 'react';
import axios from "axios";
import "./Register.css";
import { Company } from '../../models/Company';
import Home from '../home/Home';

interface RegisterState {
    name: string;
    address: string;
    phone: string;
    newId: number;
}

export default class Register extends Component<any, RegisterState> {

    public constructor(props: any) {
        super(props);
        this.state = { name: "", address: "", phone: "", newId: 0 };
    }

    private setName = (event: ChangeEvent<HTMLInputElement>) => {
        const name = event.target.value;
        this.setState({ name });
    }

    private setAddress = (event: ChangeEvent<HTMLInputElement>) => {
        const address = event.target.value;
        this.setState({ address });
    }

    private setPhone = (event: ChangeEvent<HTMLInputElement>) => {
        const phone = event.target.value;
        this.setState({ phone });
    }

    private register = async () => {
        try {
            let company = new Company(null, this.state.name, this.state.address, this.state.phone);
            const response = await axios.post<number>("http://localhost:8080/companies", company);
            const serverResponse = response.data;
            this.setState({ newId: serverResponse });
            alert("Company was successfuly created! Id is: " + this.state.newId);
            this.props.history.goBack();
        }
        catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private back = () => {
        this.props.history.goBack();
    }

    public render() {
        return (
            <div className="register">
                <h2>Register new company</h2>
                <span className="titles">
                    Name: <br />
                Address: <br />
                Phone: <br />
                </span>
                <span className="text-boxes">
                    <input type="text" name="name" value={this.state.name} onChange={this.setName} /><br />
                    <input type="text" name="address" value={this.state.address} onChange={this.setAddress} /><br />
                    <input type="number" name="phone" value={this.state.phone} onChange={this.setPhone} /><br />
                </span><br />
                <input type="button" id="button" value="Register" onClick={this.register} />
                <input type="button" id="button" value="Back" onClick={this.back} /><br />
            </div>
        );
    }

}


