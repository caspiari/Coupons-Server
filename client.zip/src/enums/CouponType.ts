export enum CouponType{
    COMPUTERS = "COMPUTERS", 
    STEREO = "STEREO", 
    KITCHEN = "KITCHEN"
}