import { Component } from 'react';
import { Coupon } from '../../models/Coupon';
import './Card.css';

interface ICardProps {
  coupon: Coupon;
  onCardClick: any;
}

export default class Card extends Component<ICardProps> {

  public constructor(props: ICardProps) {
    super(props);
  }

  public static formatDate(time, prefix = "") {
    let date = Date.parse(time); // returns NaN if it can't parse
    let dateObject = new Date(date);
    return Number.isNaN(date) ? "" : prefix + dateObject.toLocaleDateString();
  }
  
  public static formatDateAndTime(timestamp) {
    const dateObject = new Date(timestamp);
    return dateObject.toLocaleString();
}

  public render() {
    return (
        <div className="card" onClick={this.props.onCardClick}>
          <b id="id">{this.props.coupon.id}</b>
          <b id="company">{this.props.coupon.companyName}</b>
          <b id="category">{this.props.coupon.category}</b>
          <span className="name">{this.props.coupon.name}</span><br />
          {`Price: ${this.props.coupon.price}`}&emsp;&emsp; 🟦 &emsp;&emsp;
          {`Units left: ${this.props.coupon.amount}`}&emsp;&emsp; 🟦 &emsp;&emsp;
          {`Expiration date: ${Card.formatDate(this.props.coupon.endDate)}`}
        </div>

    )
  }
}

