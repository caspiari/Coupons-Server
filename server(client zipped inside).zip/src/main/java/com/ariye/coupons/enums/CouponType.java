package com.ariye.coupons.enums;

public enum CouponType {
    COMPUTERS, STEREO, KITCHEN
}
