import { Component } from 'react'
import "./Header.css";

export default class Header extends Component {
  public render() {
    return (
      <div className="header">
        Coupons website
      </div>
    );
  }
}
