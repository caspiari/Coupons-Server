import { Component } from 'react'
import welcome1021 from './welcome.png';
import welcome544 from './welcome544.png';
import "./Home.css";

export default class Home extends Component<any> {

    public constructor(props: any) {
        super(props);
    }

    public static exceptionTreatment = (err: any, props: Readonly<any>) => {
        if(err.message != null && err.message.includes("status code 401")){
            Home.loginRequset(props);
            return;
        }
        if(err.message != null && err.message.includes("status code 600")){
            console.log(err.message + JSON.stringify(err));
            alert("General error, please try again");
            return;
        }
        if (err.response != null && err.response.data != null && err.response.data.errorMessage != null) {
            let errorMessage: string = err.response.data.errorMessage;
            if(errorMessage.includes("General error")) {
                alert("General error, please try again");
            } else if (errorMessage.includes("You have no access")) {
                alert("You have no access to this action");
            } else {
                alert(errorMessage);
            }
            return;
        } else {
            console.log(JSON.stringify(err), err.message);
            alert("General error, please contact customer service");
        }
    }
    
    public static loginRequset = (props: Readonly<any>) => {
        alert("Please login/register to continue");
        props.history.push('/login');
    }

    public render() {
        return (
            <div className="home">
                <h1>Welcome to coupons website</h1>
                <input type="button" value="Our coupons" onClick={() => this.props.history.push('/coupons')} />
                <input type="button" value="Login / Register" onClick={() => this.props.history.push('/login')} />
            </div>
        );
    }
}
