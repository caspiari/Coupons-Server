import axios from 'axios';
import { Component } from 'react'
import { Company } from '../../../models/Company';
import Home from '../../home/Home';
import "./CompanyDetails.css";

interface ICompanyDetailsState {
    company: Company;
    successfulDelete: boolean;
}

export default class CompanyDetails extends Component<any, ICompanyDetailsState> {

    constructor(props: any) {
        super(props);
        this.state = { company: new Company(), successfulDelete: false };
    }

    public async componentDidMount() {
        const token = sessionStorage.getItem("token");
        axios.defaults.headers.common["Authorization"] = token;
        try {
            const id = this.props.match.params.id;
            const response = await axios.get<Company>("http://localhost:8080/companies/" + id);
            const company = response.data;
            this.setState({ company: company });
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private onDeleteClick = async () => {// eslint-disable-next-line
        if (window.confirm("Do you want to delete this company?") == true) {
            try {
                await axios.delete("http://localhost:8080/companies/" + this.state.company.id);
                alert("Company was successfuly deleted");
                this.props.history.goBack();
            } catch (err) {
                Home.exceptionTreatment(err, this.props);
            }
        }
    }

    public render() {
        return (
            <div className="companyDetails">
                <h2>Company details:</h2>
                <h3>
                    Id: {this.state.company.id}<br />
            Name: {this.state.company.name}<br />
            Address: {this.state.company.address}<br />
            Phone: {this.state.company.phone}<br />
                </h3><br /><br />
                {/* eslint-disable-next-line*/}
                {(sessionStorage.getItem("userType") == "ADMIN" || sessionStorage.getItem("userType") === "COMPANY") &&
                    <input type="button" value="Edit" onClick={() => this.props.history.push("/updateCompany/" + this.state.company.id)} />}
                {/* eslint-disable-next-line*/}
                {sessionStorage.getItem("userType") == "ADMIN" && <input type="button" value="Delete" onClick={this.onDeleteClick} />}
                <input type="button" value="Back" onClick={() => this.props.history.goBack()} /><br />
            </div>
        );
    }

}
