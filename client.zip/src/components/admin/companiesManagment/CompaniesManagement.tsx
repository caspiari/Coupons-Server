import { Component } from 'react'
import "./CompaniesManagement.css"
import axios from 'axios';
import { ChangeEvent } from 'react';
import Home from '../../home/Home';
import { Company } from '../../../models/Company';

interface ICompaniesManagementState {
    idFilter: number;
    nameFilter: string;
    cityFilter: string;
    cities: string[];
    companies: Company[];
}

export default class CompaniesManagement extends Component<any, ICompaniesManagementState> {


    constructor(props: any) {
        super(props);
        this.state = { idFilter: 0, nameFilter: "", cityFilter: "", companies: [], cities: [] };
    }

    public async componentDidMount() {
        try {
            const token = sessionStorage.getItem("token");
            axios.defaults.headers.common["Authorization"] = token;
            const response = await axios.get<Company[]>("http://localhost:8080/companies");
            const companies = response.data;
            let citiesSet = new Set<string>();
            companies.map(company => citiesSet.add(company.address.substring(company.address.lastIndexOf(" ") + 1)));
            const cities = Array.from(citiesSet);
            this.setState({ companies: companies, cities: cities });
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    private onIdPipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let idFilter = +event.target.value;
        this.setState({ idFilter });
    }

    private onNamePipeChanged = (event: ChangeEvent<HTMLInputElement>) => {
        let nameFilter = event.target.value;
        this.setState({ nameFilter });
    }

    private onCityPipeChanged = (event: ChangeEvent<HTMLSelectElement>) => {
        const cityFilter = event.target.value;
        this.setState({ cityFilter: cityFilter });
    }

    public render() {
        return (
            <div className="companiesManagement">
                <br />
                <h2>Companies management</h2>
                <br /><input type="button" value="Register new company" onClick={() => this.props.history.push("/registerCompany")} /><br /><br />
                <b>Search: </b>By id: <input type="number" id="id" onChange={this.onIdPipeChanged} />
                    &nbsp;By name: <input type="text" id="name" onChange={this.onNamePipeChanged} />
                    &nbsp; By city: <select name="citySelect" onChange={this.onCityPipeChanged}>
                    <option value={""} key="defaultCity">-- Select city --</option>
                    {this.state.cities.map((city, index) => <option value={city} key={index}>{city}</option>)}
                </select>
                <br />
                <table>
                    <thead>
                        <tr className="tableHead">
                            <th>ID</th>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        {// eslint-disable-next-line
                            this.state.companies.filter(company => this.state.idFilter == 0 ? true : company.id == this.state.idFilter)
                                .filter(company => company.name.includes(this.state.nameFilter))// eslint-disable-next-line
                                .filter(company => company.address.substring(company.address.lastIndexOf(" ") + 1).includes(this.state.cityFilter))
                                .map((company, index) =>
                                    <tr key={company.id}>
                                        <td>{company.id}</td>
                                        <td>{company.name}</td>
                                        <td>{company.address}</td>
                                        <td>{company.phone}</td>
                                        <td className="button"><input type="button" value="Show details" onClick={() => { this.props.history.push("/companyDetails/" + company.id) }} /></td>
                                    </tr>
                                )
                        }
                    </tbody>
                </table>
                <br /><input type="button" value="Back" className="back" onClick={() => this.props.history.goBack()} /><br /><br />
            </div>
        );
    }
}