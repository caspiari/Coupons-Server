import { Component, ChangeEvent } from 'react';
import axios from "axios";
import "./NewPurchase.css";
import Home from '../../home/Home';
import { Purchase } from '../../../models/Purchase';

interface NewPurchaseState {
    couponId: number;
    userId: number;
    amount: number;
    newId: number;
}

export default class NewPurchase extends Component<any, NewPurchaseState> {

    public constructor(props: any) {
        super(props);
        this.state = { couponId: 0, userId: 0, amount: 0, newId: 0 };
    }

    private setCouponId = (event: ChangeEvent<HTMLInputElement>) => {
        const couponId = +event.target.value;
        this.setState({ couponId });
    }

    private setUserId = (event: ChangeEvent<HTMLInputElement>) => {
        const userId = +event.target.value;
        this.setState({ userId });
    }

    private setAmount = (event: ChangeEvent<HTMLInputElement>) => {
        const amount = +event.target.value;
        this.setState({ amount });
    }

    private onCreateClick = async () => {
        const purchase = new Purchase(null, this.state.couponId, this.state.userId, this.state.amount);
        try {
            const response = await axios.post<number>("http://localhost:8080/purchases", purchase);
            const serverResponse = response.data;
            this.setState({ newId: serverResponse });
            alert("Purchase was successfuly created! Id is: " + this.state.newId);
            this.props.history.goBack();
        } catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    public render() {
        return (
            <div className="newPurchase">
                <h2>New purchase</h2>
                <span className="titles">
                Amount: <br />
                Buyer id: <br />
                Coupon id: <br />
                </span>
                <span className="text-boxes">
                    <input type="number" name="amount" value={this.state.amount} onChange={this.setAmount} /><br />
                    <input type="number" name="buyer" value={this.state.userId} onChange={this.setUserId} /><br />
                    <input type="number" name="couponId" value={this.state.couponId} onChange={this.setCouponId} /><br />
                </span><br /><br />
                <input type="button" value="Create" id="button" onClick={this.onCreateClick} />
                <input type="button" value="Back" id="button" onClick={() => this.props.history.goBack()} />

            </div>
        );
    }

}