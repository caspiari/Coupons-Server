export enum ActionType {
    LOGIN, FOR_IF_ADMIN_COMPONENT 
}