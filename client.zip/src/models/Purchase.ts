export class Purchase {
    public constructor(
        public id?:number,
        public userId?:number,
        public couponId?:number,
        public amount?:number,
        public timestamp?:Date,
        public couponName?:string,
        public companyName?:string,
        public username?:string
    ){}
}