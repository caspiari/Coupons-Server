import { Component, ChangeEvent } from 'react';
import axios from "axios";
import "./Register.css";
import { User } from '../../models/User';
import { UserType } from '../../enums/UserType';
import { Company } from '../../models/Company';
import IfAdmin from './ifAdmin/IfAdmin';
import Home from '../home/Home';

interface RegisterUserState {
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    userType: UserType;
    companyId?: number;
    companies: Company[];
    newId: number;
}

export default class RegisterUser extends Component<any, RegisterUserState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            username: "", password: "", firstName: "", lastName: "", userType: UserType.CUSTOMER,
            companies: [], newId: 0
        };
    }

    private setUsername = (event: ChangeEvent<HTMLInputElement>) => {
        const username = event.target.value;
        this.setState({ username });
    }

    private setPassword = (event: ChangeEvent<HTMLInputElement>) => {
        const password = event.target.value;
        this.setState({ password });
    }

    private setFirstName = (event: ChangeEvent<HTMLInputElement>) => {
        const firstName = event.target.value;
        this.setState({ firstName });
    }

    private setLastName = (event: ChangeEvent<HTMLInputElement>) => {
        const lastName = event.target.value;
        this.setState({ lastName });
    }

    private setUserType = (userType: UserType) => {
        this.setState({ userType });
    }

    private setCompanyId = (event: ChangeEvent<HTMLSelectElement>) => {
        const companyId = +event.target.value;
        this.setState({ companyId });
    }

    private register = async () => {
        try {
            let user = new User(null, this.state.username, this.state.password, this.state.firstName, this.state.lastName,
                this.state.userType, this.state.companyId);
            const response = await axios.post<number>("http://localhost:8080/users", user);
            const serverResponse = response.data;
            user.id = serverResponse;
            this.setState({ newId: user.id });
            alert("Successful registration! Your user id is: " + this.state.newId);
            this.props.history.goBack();
        }
        catch (err) {
            Home.exceptionTreatment(err, this.props);
        }
    }

    public render() {
        return (
            <div className="register">
                <h2>Register new user</h2>
                User name: <input type="text" name="username" placeholder="E-mail" value={this.state.username} onChange={this.setUsername} /><br />
                Password:&nbsp; <input type="password" name="password" value={this.state.password} onChange={this.setPassword} /><br />
                First name: <input type="text" name="firstName" value={this.state.firstName} onChange={this.setFirstName} /><br />
                Last name: <input type="text" name="lastName" value={this.state.lastName} onChange={this.setLastName} /><br />
                {sessionStorage.getItem("userType") === UserType.ADMIN.valueOf() && <IfAdmin setUserType={this.setUserType} setCompanyId={this.setCompanyId} />}
                <br />
                <input type="button" id="button" value="Register" onClick={this.register} />
                <input type="button" id="button" value="Back" onClick={() => this.props.history.goBack()} />
            </div>
        );
    }

}


