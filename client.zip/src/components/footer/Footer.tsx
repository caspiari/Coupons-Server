import { Component } from 'react'
import "./Footer.css";

export default class Footer extends Component {
  public render() {
    return (
      <div className="footer">
        All Rights Reserved
      </div>
    );
  }
}
